document.addEventListener('DOMContentLoaded', function() {
    var mixer = mixitup('.product-filter-items');
});